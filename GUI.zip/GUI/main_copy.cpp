#include <iostream>
#include <string>
#include <array>
#include <vector>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <stdio.h>



class GUI{
private:
    cv::String imgtext;

    cv::Mat gui;

    //background
    int gwidth = 1400;
    int gheight = 800;

public:

    cv::Mat gui_r;

    GUI(){
        std::cout << "no" << std::endl;
    }

    GUI(std::string navn){
        gui = imread("../img/"+navn+".png", cv::IMREAD_COLOR);
    }

    void resizegui(){
        cv::resize(gui,gui_r, cv::Size(gwidth, gheight), cv::INTER_LINEAR);
    }

};

class button: public GUI{
private:
    cv::Mat butt, butt_r;

    int bwidth = 150;
    int bheight = 150;

    cv::Rect button1;
    cv::Rect button2;
    cv::Rect button3;

    std::vector <cv::Rect> buttons;
    int hihi = 0;

public:
    button(){
        std::cout << "no" << std::endl;
    }
    button(std::string navn){
        butt = imread("../img/green/"+navn+".png", cv::IMREAD_COLOR);
    }

    void makebutt(int x, int y){
        cv::resize(butt, butt_r, cv::Size(bwidth, bheight), cv::INTER_LINEAR);
        cv::Rect button = cv::Rect(x, y, bwidth, bheight);

        cv::Mat insert(gui_r, button);
        butt_r.copyTo(insert);
    }
    void showimage(){
        std::string imgtext = "Our GUI";
        cv::namedWindow(imgtext);
        resizegui();
        makebutt(300, 550);
        cv::imshow(imgtext, gui_r);
    }
};



int main(){

    /*cv::Mat pic = imread("../img/green/apple.png", cv::IMREAD_COLOR);

    int imggui_width = 1400;
    int imggui_height = 800;
    cv::Mat picr;
    cv::resize(pic,picr, cv::Size(imggui_width, imggui_height), cv::INTER_LINEAR);
    std::string imgtext = "Our GUI";
    cv::namedWindow(imgtext);
    cv::imshow(imgtext, picr);*/

    //GUI gui("biggerscratch");
    //button apple("apple");


    //apple.showimage();

    cv::waitKey(0);
    return 0;
}
